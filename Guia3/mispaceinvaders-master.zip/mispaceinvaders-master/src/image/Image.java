package image;

public enum Image {
  UFO, BOMB, LASER, SPACESHIP, BACKGROUND;
}
